package base;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;
import utilities.ConfigReader;

import java.util.Properties;

public class BaseTest {

    public Properties prop;
    public WebDriver driver;
    public SoftAssert softAssert;

    @BeforeClass
    public void setUp() {
        prop = ConfigReader.getProperties();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(prop.getProperty("url"));
    }

//    @AfterMethod
//    public void tearDown() {
//        driver.close();
//    }
}
