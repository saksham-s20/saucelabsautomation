package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import utilities.ConfigReader;

import java.time.Duration;

import static org.testng.Assert.assertTrue;

public class MainTest extends base.BaseTest {
    @Test
    public void atitleCheck(){
        String expectedString = "Swag Labs";
        String actualString = driver.getTitle();
        Assert.assertEquals(expectedString,actualString, "title does not match");
        System.out.println("The title matches perfectly!");
    }
    @Test
    public void bpageLoadCheck(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement passwordText = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//h4[contains(text(),'Password for all users')]")
        ));
        String actualPresent = passwordText.getText();
        String expected = "Password for all users:";
        Assert.assertEquals(actualPresent, expected,"the page has not loaded successfully!");
        System.out.println("The webpage has loaded successfully!");
    }
    @Test
    public void cfieldsCheck() throws InterruptedException{
        prop = ConfigReader.getProperties();
        String username = prop.getProperty("username");
        String password = prop.getProperty("password");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys(username);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys(password);
        Thread.sleep(2000);
    }
    @Test
    public void dloginButtonCheck() throws InterruptedException{
        WebElement loginButton = driver.findElement(By.xpath("//input[@id='login-button']"));
        assertTrue(loginButton.isDisplayed(), "Login button is not displayed.");
        assertTrue(loginButton.isEnabled(), "Login button is not enabled.");
        System.out.println("Login button assertions passed successfully!");
        driver.findElement(By.id("login-button")).click();
        Thread.sleep(5000);
    }
    @Test
    public void ebagandshirtCheck() throws InterruptedException {
        // to check if bag is visible
        WebElement bag = driver.findElement(By.xpath("//div[contains(@class, \"inventory_item_name \")]"));
        String bagtext = bag.getText();
        String bagCheck = "Sauce Labs Backpack";
        Assert.assertEquals(bagtext, bagCheck, "Text is not correct");

        // to check is shirt is visible
        WebElement shirt = driver.findElement(By.xpath("//div[contains(text(), \"Sauce Labs Bolt T-Shirt\")]"));
        String shirttext = shirt.getText();
        String shirtCheck = "Sauce Labs Bolt T-Shirt";
        Assert.assertEquals(shirttext, shirtCheck, "Text is not correct");

        //price of bag
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        String bagValue = driver.findElement(By.xpath("//div[contains(@class, \"inventory_item_price\")]")).getText();
        System.out.println(bagValue);
        String bagWithout = bagValue.replace("$", "");
        double dbag = Double.parseDouble(bagWithout);

        //price of shirt
        driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();
        String shirtValue = driver.findElement(By.xpath("(//div[contains(@class, \"inventory_item_price\")])[3]")).getText();
        System.out.println(shirtValue);
        String shirtWithout = shirtValue.replace("$", "");
        double dshirt = Double.parseDouble(shirtWithout);

        double total = dshirt + dbag;
        String stotal = String.valueOf(total);
        System.out.println(total);
        //going to cart
        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[contains(@class, \"shopping_cart_link\")]")).click();
    }
    @Test
    public void fcart() throws InterruptedException{
        //checking if enterd the cart or not

        WebDriverWait g = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement qty = g.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, \"cart_quantity_label\")]")));

        String cart = driver.findElement(By.xpath("//span[contains(text(), \"Your Cart\")]")).getText();
        String cartCheck = "Your Cart";
        Assert.assertEquals(cart, cartCheck, "Not able to reach cart");
        Thread.sleep(2000);
        //moving ahead to cart
        driver.findElement(By.id("checkout")).click();

        // checking if reached to form or not
        String form = driver.findElement(By.xpath("//span[contains(@class,\"title\")]")).getText();
        String formCheck = "Checkout: Your Information";
        Assert.assertEquals(form, formCheck, "Not able to reach form");

        //filling form
        Thread.sleep(2000);
        String firstName = prop.getProperty("firstName");
        driver.findElement(By.id("first-name")).sendKeys(firstName);
        Thread.sleep(1000);
        String lastName = prop.getProperty("lastName");
        driver.findElement(By.id("last-name")).sendKeys(lastName);
        Thread.sleep(1000);
        String postalCode = prop.getProperty("postalCode");
        driver.findElement(By.id("postal-code")).sendKeys(postalCode);
        Thread.sleep(1000);
        driver.findElement(By.id("continue")).click();
        Thread.sleep(2000);
    }
    @Test
    public void gend() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 1148)");
        Thread.sleep(1000);
        driver.findElement(By.id("finish")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("back-to-products")).click();
    }
    @Test
    public void habout() throws InterruptedException{
        driver.findElement(By.xpath("//button[@id='react-burger-menu-btn']")).click();
        WebElement aboutButton = driver.findElement(By.xpath("//a[@id='about_sidebar_link']"));
        assertTrue(aboutButton.isEnabled(),"the about button is not displayed");
        Thread.sleep(1000);
        aboutButton.click();
//        Thread.sleep(5000);
//        WebElement popupButton = driver.findElement(By.xpath("//button[@id='onetrust-accept-btn-handler']"));
//        softAssert.assertTrue(popupButton.isDisplayed(),"the popup method is not displayed!");
//        Alert a = driver.switchTo().alert();
//        a.accept();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement popButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[@id='onetrust-accept-btn-handler']")
        ));
        popButton.click();
    }
    @Test
    public void navigationCheck() throws InterruptedException{
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, 7060)");
        Thread.sleep(4000);
        js.executeScript("window.scrollTo(0,0)");
        Thread.sleep(2000);
        WebElement signUpButton = driver.findElement(By.xpath("//h1[text()='Build apps users love with AI-driven insights']"));
        Assert.assertTrue(signUpButton.isDisplayed(), "the button is not visible!");
        System.out.println("All the test cases are executed and passed!");
    }
}